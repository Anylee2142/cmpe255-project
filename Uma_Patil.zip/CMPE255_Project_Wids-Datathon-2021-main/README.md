# CMPE255_Project_Wids-Datathon-2021

1. pip install virtualenv or sudo apt install virtualenv
2. virtualenv --python=YOUR_PYTHON cmpe255-project
3. source cmpe255-project/bin/activate
4. pip install -r requirements.txt
5. ipython kernel install --user --name=cmpe255-project
6. jupyter lab
7. Choose the cmpe255-project kernel
